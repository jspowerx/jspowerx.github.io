var entry = [
    'main.js'
];